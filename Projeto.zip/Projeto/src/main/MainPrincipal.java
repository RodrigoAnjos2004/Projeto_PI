
package main;

import view.ViewLogin;

/**
 *
 * @author AnjosRdorigo2004
 */
public class MainPrincipal {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ViewLogin frm = new ViewLogin(); // Instancia do Objeto
        frm.setVisible(true);// Visualizando o arquivo
    }
}

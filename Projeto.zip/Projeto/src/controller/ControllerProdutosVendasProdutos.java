package controller;

import DAO.DAOProdutosVendasProdutos;
import java.util.ArrayList;
import model.ModelProdutosVendasProdutos;

/**
 *
 * @author AnjosRodrigo2004
 */
public class ControllerProdutosVendasProdutos {
    
    private DAOProdutosVendasProdutos daoProdutosVendasProdutos = new DAOProdutosVendasProdutos();
    
    public ArrayList<ModelProdutosVendasProdutos> getListaProdutosVendasProdutosController(int pCodigoVeda){
        return this.daoProdutosVendasProdutos.getListaProdutosVendasProdutosDAO(pCodigoVeda);
    }
}
